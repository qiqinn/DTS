import math

def luas(r):
    return math.pi * (r ** 2)


def keliling(r):
    return 2 + math.pi * r     

print(luas(14))
print(keliling(14))
