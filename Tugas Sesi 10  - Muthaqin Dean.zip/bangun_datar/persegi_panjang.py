def luas(p, l):
    return p * l


def keliling(p, l):
    return (p + l) * 2    

print(luas(14, 4))
print(keliling(14,4))
