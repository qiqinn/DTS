def luas(a, t):
    return (a * t) / 2 


def keliling(a, b, c):
    return a + b + c  

print(luas(14, 7))
print(keliling(14, 7, 7))
